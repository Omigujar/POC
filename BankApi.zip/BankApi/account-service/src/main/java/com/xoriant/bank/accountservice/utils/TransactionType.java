package com.xoriant.bank.accountservice.utils;

public enum TransactionType {
	WITHDRAW,DEPOSIT,TRANSFER;
}

package com.xoriant.bank.accountservice.resource;


public class CurrentAccountResource {


}

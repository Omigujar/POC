package com.xoriant.bank.managerservice.utils;

public enum Gender {
	MALE,FEMALE
}

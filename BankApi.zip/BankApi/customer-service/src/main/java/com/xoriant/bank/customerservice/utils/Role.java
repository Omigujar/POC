package com.xoriant.bank.customerservice.utils;

public enum Role {
MANAGER,CUSTOMER;
}

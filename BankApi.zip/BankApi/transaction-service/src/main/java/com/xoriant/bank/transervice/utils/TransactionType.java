package com.xoriant.bank.transervice.utils;

public enum TransactionType {
	WITHDRAW,DEPOSIT,TRANSFER;
}
